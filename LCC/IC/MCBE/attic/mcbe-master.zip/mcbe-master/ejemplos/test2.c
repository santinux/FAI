int main()
{
	int ai8;

	ai8 = 16;
}
