int main()
{
	int a;
	int b = 2;
	a = b + 5; 
	a = 5 + b;
	b = b + 3;
	b = 3 + b;
}

