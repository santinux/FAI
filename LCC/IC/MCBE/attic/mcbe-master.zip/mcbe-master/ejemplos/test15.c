int main()
{
	int a = 0; 

	while(a != 10) {
		out(a);
		a++;
	}
}
