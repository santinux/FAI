int main()
{
	int a;

	in(&a);
	if(a != 10) {
		a++;
	}
	out(a);
}
