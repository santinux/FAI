int main()
{
	int a = 25;

	a = a - 128;
	out(a);

	a = a + 127;
	a++;

	out(a);

}
