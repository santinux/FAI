int main()
{
	int k2;
	int b = 1;
	int c = 2;

	in(&k2);

	if(k2 != 8) {
		out(b);
	}
	if(k2 != 2) {
		out(c);
	}
}
