int main() 
{
	int a;
	int b = 2;
	b = 3 - b;
	a = 1 - b;
}
