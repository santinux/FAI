int main()
{
	int a = 18;
	int b;


	b = 0 - a;
	b--;

	out(a);
	out(b);
}
