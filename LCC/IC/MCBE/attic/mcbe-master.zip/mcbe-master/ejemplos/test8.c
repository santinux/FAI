int main()
{
   int a1;
   int b = 1;
int cad2;

	a1++;

	b = cad2;
}
