int main()
{
   int b = 1;
   int c;
   c = 6;
   b++; 
   c--; 
}
