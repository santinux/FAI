int main() 
{
	int a;
	int b = 2;
	a = b + 5; 
	a++;
	b = 3 - b;
	b--;

}
