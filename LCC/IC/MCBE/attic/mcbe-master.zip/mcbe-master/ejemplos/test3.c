int main()
{
	int a;
	int b = 2;
	int c;
	c = 3;
	a = 1 + 5; 
	c = 2 - 7;
}

