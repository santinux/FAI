int main()
{
	int a;
	int b = 2;
	int c;
	c = 3;
	a = 1 + 5; 
	in(&b);
	out(a);
}

