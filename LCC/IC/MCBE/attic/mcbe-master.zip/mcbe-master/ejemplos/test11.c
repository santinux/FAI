int main()
{
	int a;
	int b;

	while(a != 10) {
		b = b + a;
		a++;
	}
	out(b);
}
