int main()
{
	int a = 0;
	int b = 0;

	while(a != 4) {
		a++;
	}
	while(b != a) {
		b++;
	}
}

