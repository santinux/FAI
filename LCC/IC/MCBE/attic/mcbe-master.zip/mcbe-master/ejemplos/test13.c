// imprimir cuenta desde 1 hasta a
// a input de usuario

int main()
{
	int a;
	int b = 1;

	in(&a);
	while(b != a) {
		out(b);	
		b++;
	}
}

