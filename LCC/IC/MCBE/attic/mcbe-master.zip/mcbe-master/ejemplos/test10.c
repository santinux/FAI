int main()
{
   int a;
   
   in(&a);
   a++;
   out(a);
}
